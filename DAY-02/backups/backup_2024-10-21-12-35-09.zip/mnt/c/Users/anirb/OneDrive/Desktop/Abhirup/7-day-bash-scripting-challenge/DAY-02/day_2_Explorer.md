# Day 2 Bash Scripting Challenge - Interactive File and Directory Explorer
Welcome to Day 2 of the Bash Scripting Challenge! In this challenge, you will create a bash script that serves as an interactive file and directory explorer. The script will allow you to explore the files and directories in the current path and provide a character counting feature for the user's input.
Challenge Description

The script will have two main parts:

# Part 1: File and Directory Exploration
    Upon execution without any command-line arguments, the script will display a welcome message and list all the files and directories in the current path.
    For each file and directory, the script will print its name and size in human-readable format (e.g., KB, MB, GB). This information will be obtained using the ls command with appropriate options.
    The list of files and directories will be displayed in a loop until the user decides to exit the explorer.

# Part 2: Character Counting
    After displaying the file and directory list, the script will prompt the user to enter a line of text.
    The script will read the user's input until an empty string is entered (i.e., the user presses Enter without any text).
    For each line of text entered by the user, the script will count the number of characters in that line.
    The character count for each line entered by the user will be displayed.
